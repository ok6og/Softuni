﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Figures
{
    public interface IDrawable
    {
        void Draw();
    }
}
