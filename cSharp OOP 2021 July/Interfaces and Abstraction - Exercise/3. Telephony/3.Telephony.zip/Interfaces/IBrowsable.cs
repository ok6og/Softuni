﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3._Telephony.Interfaces
{
    public interface IBrowsable
    {
        public string Browse(string url);
    }
}
