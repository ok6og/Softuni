﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3._Telephony.Interfaces
{
    public interface ICallable
    {
        public string Call(string phoneNumber);
    }
}
